# Name: Main.py
# Author: Super3boy (super3.org)

# System Imports
import pygame
import os

# My Imports
from helper import *
from blocks import *

# Start PyGame
pygame.init()

# Define Basic Colors
black = [0, 0 ,0]
white = [255, 255, 255]
blue = [ 0, 0 , 255]
green = [ 0, 255, 0]
red = [255, 0, 0]

# Define Game Colors
darkgrey = [84, 87, 106]
lightgrey = [165, 166, 174]
		
# Set and Display Screen
sizeX = 800
sizeY = 200
size = [sizeX, sizeY]
# Load Icon
seticon('icon2.png')
screen = pygame.display.set_mode(size)

# Set Screen's Title and Icon
pygame.display.set_caption("Zombies on Conveyors")

# Sentinel for Game Loop
done = False

# Game Timer
clock = pygame.time.Clock()

# all_sprites - contains all the sprites to be rendered
# zombie_sprites - contains only the zombies, used for collisions mostly
all_sprites = pygame.sprite.RenderPlain()
zombie_sprites = pygame.sprite.RenderPlain()

# Load Images and Create Animated Sprite Objects
zombie_sprite = load_sliced_sprites(23, 34, "zombie.png")
zombie_die_sprite = load_sliced_sprites(35, 34, "zombie-die.png")
police_fire = load_sliced_sprites(35, 34, "police-fire.png")

# Load Background
background_image = pygame.image.load("factory-background.png").convert()

# Load Crosshairs
crosshair = Block(50, 50, "crosshair.png")
all_sprites.add(crosshair)

# Load Police
police = Police(police_fire, 20, sizeY-34)
all_sprites.add(police)

# Load a Few Zombies
for i in range(3):
	a_zombie = Zombie(zombie_sprite, sizeX+(i*30), sizeY-34)
	all_sprites.add(a_zombie)
	zombie_sprites.add(a_zombie)

# Hide Mouse
pygame.mouse.set_visible(False)

# Main Game Loop
while done == False:
	# Limit FPS of Game Loop
	clock.tick(30)
	
	# Check for Events
	for event in pygame.event.get(): 
		# Quit Game
		if event.type == pygame.QUIT:
			done = True
		# Spawn a Zombie
		elif event.type == pygame.KEYDOWN:
			if event.key == pygame.K_z:
				#print("Zombie Spawned!")
				a_zombie = Zombie(zombie_sprite, sizeX+30, sizeY-34)
				all_sprites.add(a_zombie)
				zombie_sprites.add(a_zombie)
		# Fire Weapon
		elif event.type != pygame.MOUSEBUTTONDOWN:
			police.canFire = False
		elif event.type != pygame.MOUSEBUTTONUP:
			police.canFire = True
			
	# Set Movement
	key=pygame.key.get_pressed()  #checking pressed keys
	
	# Move Police
	if key[pygame.K_a]:
		police.moveLeft()
	elif key[pygame.K_d]:
		police.moveRight()
			
	# Clear the Screen
	screen.fill(white)
	
	# Gets the current mouse position
	# Returns the postition as a list of two numbers
	pos = pygame.mouse.get_pos()
	
	# Set the mouse position to the player block
	crosshair.rect.x = pos[0] + 5
	crosshair.rect.y = pos[1] + 5
	
	# Show Background
	screen.blit( background_image , [0 ,0])
	
	# Display Sprites
	for i in all_sprites:
		i.render(screen)
		
	# See if the player block has collided with anything
	if police.canFire:
		block_hit_list = pygame.sprite.spritecollide(crosshair, zombie_sprites, True)
	else: 
		block_hit_list = pygame.sprite.spritecollide(crosshair, zombie_sprites, False)
	
	#Check the list of collisions and reset hit blocks 
	if len(block_hit_list) > 0:
		for i in block_hit_list:
			print("Hit")

	# Update Display
	pygame.display.flip()

# Exit Program
pygame.quit()