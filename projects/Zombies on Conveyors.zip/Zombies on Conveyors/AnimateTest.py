# Name: Main.py
# Author: Super3boy (super3.org)

# System Imports
import pygame
import os

# My Imports
from helper import *
from blocks import *

# Start PyGame
pygame.init()

# Define Basic Colors
black = [0, 0 ,0]
white = [255, 255, 255]
blue = [ 0, 0 , 255]
green = [ 0, 255, 0]
red = [255, 0, 0]

# Define Game Colors
darkgrey = [84, 87, 106]
lightgrey = [165, 166, 174]
		
# Set and Display Screen
sizeX = 400
sizeY = 400
size = [sizeX, sizeY]
# Load Icon
screen = pygame.display.set_mode(size)

# Set Screen's Title and Icon
pygame.display.set_caption("Zombies on Conveyors")

# Sentinel for Game Loop
done = False

# Game Timer
clock = pygame.time.Clock()

# These are two lists of sprites.
# The list is managed by a class called 'RenderPlain.'
zombie_sprites = pygame.sprite.RenderPlain()
all_sprites = pygame.sprite.RenderPlain()

# Load Images and Create Animated Sprite Objects
zombie1 = load_sliced_sprites(23, 34, "zombie.png")
zombie2 = load_sliced_sprites(23, 34, "zombie.png")

# Load Zombies
zom1 = AnimatedBlock(zombie1, 100, 100)
zom2 = AnimatedBlock(zombie2, 200, 200)
all_sprites.add(zom1)
all_sprites.add(zom2)
zombie_sprites.add(zom1)
zombie_sprites.add(zom2)

# Load Crosshairs
crosshair = Block(50, 50, "crosshair.png")
all_sprites.add(crosshair)

# Hide Mouse
pygame.mouse.set_visible(False)

# Main Game Loop
while done == False:
	# Limit FPS of Game Loop
	clock.tick(30)
	
	# Check for Events
	for event in pygame.event.get(): 
		# Quit Game
		if event.type == pygame.QUIT:
			done = True

	# Clear Screen	
	screen.fill(white)
	
	# Gets the current mouse position
	# Returns the postition as a list of two numbers
	pos = pygame.mouse.get_pos()
	
	# Set the mouse position to the player block
	crosshair.rect.x = pos[0] + 5
	crosshair.rect.y = pos[1] + 5
	
	# Display Sprites
	for i in all_sprites:
		i.render(screen)
		
	# See if the player block has collided with anything
	block_hit_list = pygame.sprite.spritecollide(crosshair, zombie_sprites, False)
	
	# Check the list of collisions and reset hit blocks 
	if len(block_hit_list) > 0:
		for i in block_hit_list:
			print("Hit")

	# Update Display
	pygame.display.flip()

# Exit Program
pygame.quit()